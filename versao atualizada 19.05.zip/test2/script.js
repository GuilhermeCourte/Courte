function filtrarPorEstado() {
    var estadoSelecionado = document.getElementById('estado').value;
    var regiaoSelecionada = document.getElementById('regiao').value;

    atualizarResultado(estadoSelecionado, regiaoSelecionada);
}

function filtrarPorRegiao() {
    var estadoSelecionado = document.getElementById('estado').value;
    var regiaoSelecionada = document.getElementById('regiao').value;

    atualizarResultado(estadoSelecionado, regiaoSelecionada);
}

function atualizarResultado(estado, regiao) {
    var resultadoDiv = document.getElementById('resultado');
    var conteudo = '';

    // Lógica para exibir o conteúdo correspondente ao estado e à região selecionados
    switch (estado) {
        case 'SP':
            conteudo = '<h2>São Paulo</h2>';
            break;
        case 'RJ':
            conteudo = '<h2>Rio de Janeiro</h2>';
            break;
        case 'PA':
            conteudo = '<h2>Pará</h2>';
            break;
        default:
            conteudo = '<p>Selecione um estado para ver mais informações.</p>';
    }

    switch (regiao) {
        case 'norte':
            conteudo += '<p>Região Norte</p><p>Conteúdo específico da região Norte.</p>';
            conteudo += '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1948406702235!2d-46.63338688456312!3d-23.55051978467976!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce597b6be6a4b1%3A0x144ccf616a0716f1!2sS%C3%A3o%20Paulo%2C%20SP!5e0!3m2!1sen!2sbr!4v1621965047827!5m2!1sen!2sbr" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>';
            break;
        case 'sul':
            conteudo += '<p>Região Sul</p><p>Conteúdo específico da região Sul.</p>';
            conteudo += '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1948406702235!2d-46.63338688456312!3d-23.55051978467976!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce597b6be6a4b1%3A0x144ccf616a0716f1!2sS%C3%A3o%20Paulo%2C%20SP!5e0!3m2!1sen!2sbr!4v1621965047827!5m2!1sen!2sbr" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>';
            break;
        case 'leste':
            conteudo += '<p>Região Leste</p><p>Conteúdo específico da região Leste.</p>';
            conteudo += '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1948406702235!2d-46.63338688456312!3d-23.55051978467976!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce597b6be6a4b1%3A0x144ccf616a0716f1!2sS%C3%A3o%20Paulo%2C%20SP!5e0!3m2!1sen!2sbr!4v1621965047827!5m2!1sen!2sbr" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>';
            break;
        case 'oeste':
            conteudo += '<p>Região Oeste</p><p>Conteúdo específico da região Oeste.</p>';
            conteudo += '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1948406702235!2d-46.63338688456312!3d-23.55051978467976!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce597b6be6a4b1%3A0x144ccf616a0716f1!2sS%C3%A3o%20Paulo%2C%20SP!5e0!3m2!1sen!2sbr!4v1621965047827!5m2!1sen!2sbr" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>';
            break;
        default:
            conteudo += '<p>Selecione uma região para ver mais informações.</p>';
    }

    resultadoDiv.innerHTML = conteudo;
}



// Usamos += no conteúdo para concatenar as strings ao conteúdo existente. Isso é necessário porque, inicialmente, estamos definindo conteudo como uma string vazia (''). Em seguida, queremos adicionar mais conteúdo à variável conteudo com base nas escolhas feitas pelo usuário (estado e região). Se usássemos apenas =, estaríamos substituindo o conteúdo existente a cada vez, em vez de adicionar ao conteúdo anterior.
//Por exemplo, se tivéssemos apenas =:


//conteudo = '<h2>São Paulo</h2>';
//e depois

//conteudo = '<p>Região Norte</p>';
//o segundo conteudo = ... substituiria completamente o primeiro, e acabaríamos apenas com o conteúdo "Região Norte".

//No entanto, ao usar +=, estamos adicionando conteúdo ao que já existe:


//conteudo += '<h2>São Paulo</h2>';
//e depois


//conteudo += '<p>Região Norte</p>';
//Isso resultaria em conteudo contendo ambas as strings concatenadas, ou seja, "São Paulo" e "Região Norte".

//Espero que isso esclareça o motivo pelo qual usamos += para construir o conteúdo dinâmico.